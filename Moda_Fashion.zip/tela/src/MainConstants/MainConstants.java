/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainConstants;

/**
 *
 * @author victor.rslucca
 */
public class MainConstants {
    //URL de conexão com o banco de dados
    public static final String DB_ADDRESS
            = "jdbc:derby://localhost:1527/Moda_Fashion";
    //Usuário de conexão com o banco de dados
    public static final String DB_USER = "victor";
    //Senha de conexão com o banco de dados
    public static final String DB_PASS = "loja";
}
